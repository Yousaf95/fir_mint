# FIR-MINT Extensions Campaign — Runbook V4 (E6: fast-path detection + ski-rental switching)

**For: Claude Code / GitHub Copilot agent on HPC4DS.** Deadline-driven (ICDE 2027, 11 November 2026): finish all runs by **Monday 9 November**. Read the whole file first. Same rules as V2/V3: no changes to any existing code, no tuning of constants, failed runs kept and reported, results reported exactly as produced.

## 1. What this adds

`fir_extensions.py` (new file) imports the frozen `fir_mint_v4.py` and `fir_baselines.py` without modifying them and evaluates two new mechanisms on the same scenarios, seeds and window samples as E4:

- **FIR+fast:** besides the 2-window sustained-drift rule, re-tune after one window whose divergence exceeds mean + 10σ of the bootstrap distribution.
- **FIR+SR (ski-rental switching):** after detection, accumulate the excess query time of keeping the old configuration and switch once it reaches the build time of the new indexes. Evaluated at 1,000 / 10,000 / 100,000 queries per window.
- Also **FIR+fast+SR**, plus references: Static, hindsight re-tune, FIR+detector, Full+detector, Continuous FIR.
- Metrics: query-cost regret, false re-tunes, delay, builds, what-if calls, and **total time = query time + index build time**. Plus a fast-path threshold sweep (6σ / 10σ / 15σ).

**Synthetic is already done** (run against the frozen code; results and checksums in `extensions_synthetic/`). Only real data runs on the cluster.

Note: the estimator calibrates latency from real timing at the start of each run, so absolute costs differ slightly between runs. All comparisons are paired **within** a run; do not compare absolute numbers across E4 and E6.

## 2. Setup (T0)

1. Copy `fir_extensions.py` into `$RAO/code_frozen/`.
2. Verify checksums against `extensions_synthetic/CODE_SHA256.txt`:
   ```bash
   cd $RAO/code_frozen && sha256sum fir_mint_v4.py fir_baselines.py fir_extensions.py
   ```
   All three must match the file. If not, stop and report.
3. Append to `CHANGES.md`:
   ```
   ## V4 (extensions campaign)
   - Added fir_extensions.py (new file; imports frozen fir_mint_v4.py and fir_baselines.py, no modification).
   ```
   Then `sha256sum fir_extensions.py > SHA256SUMS_V4`.
4. Smoke test (about 30–90 s on synthetic):
   ```bash
   cd $RAO/runs && mkdir -p smoke_v4 && cd smoke_v4
   PYTHONPATH=$RAO/code_frozen python $RAO/code_frozen/fir_extensions.py --seeds 0 --skip_sweep --out ./smoke
   ```
   `smoke/extensions.md` must contain four scenario sections, each with a query-cost table and a total-time table.

## 3. Embeddings

The V3 runs used regenerated embeddings in `$RAO/embeddings/flickr_28k_4col`, `$RAO/embeddings/coco_30k_6col`, and the COCO 4-column folder used for `baselines_coco4`. Check that they still exist and have the expected shapes. If any was deleted, regenerate it exactly as in `RUN_EXPERIMENTS_V3.md` section 2b (same scripts, same seed) and note this in `RUN_LOG.md`.

## 4. Runs (one PBS CPU job each, run in parallel)

All with `PYTHONPATH=$RAO/code_frozen`, `FIR_BUILD_THREADS=8`, CPU queue, 8 CPUs, 64 GB, walltime 24 h.

| Task | Command | Output |
|---|---|---|
| T1 Flickr30k 4 col (**required**) | `python $RAO/code_frozen/fir_extensions.py --data $RAO/embeddings/flickr_28k_4col --out $RAO/runs/ext_flickr4` | `runs/ext_flickr4/` |
| T2 COCO 6 col (**required**) | `python $RAO/code_frozen/fir_extensions.py --data $RAO/embeddings/coco_30k_6col --out $RAO/runs/ext_coco6` | `runs/ext_coco6/` |
| T3 COCO 4 col (**required**) | `python $RAO/code_frozen/fir_extensions.py --data <COCO 4-col folder used for baselines_coco4> --out $RAO/runs/ext_coco4` | `runs/ext_coco4/` |

PBS template: copy `run_baselines_coco4.pbs` and change only the command line and job name.

Expected run time: similar to the corresponding V3 baselines run.

## 5. Checks for every run

1. **Recall:** "Viol." is 0.000 for every adaptive policy (all rows except Static). Otherwise move the run to `FINAL_RESULTS/rejected_runs/` with the reason, and report.
2. **Completeness:** 4 scenarios, each with the query-cost table (5 policies + 3 FIR+SR + 3 FIR+fast+SR rows) and the total-time table; fast-path sweep table present (12 rows).
3. **Log:** command, job ID, host, wall time, exit status in `RUN_LOG.md`.

Do not interpret or summarize beyond the checks; report results as produced.

## 6. Bundle and push

Copy each output folder to `FINAL_RESULTS/extensions/<flickr4|coco6|coco4>/` and `extensions_synthetic/` to `FINAL_RESULTS/extensions/synthetic/`. Commit and push to the repository. Reply with the content of each `extensions.md`, the run log entries, and any rejected run with its reason.
